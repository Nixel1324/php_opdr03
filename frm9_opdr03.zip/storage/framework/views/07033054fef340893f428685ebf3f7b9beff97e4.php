<?php $__env->startSection('title', 'Customer List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h1>Customers</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <form action="customers" method="POST">
                <div class="form-group pb-2">
                    <label for="name">Name:</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
                    <div><?php echo e($errors->first('name')); ?></div>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
                    <div><?php echo e($errors->first('email')); ?></div>
                </div>

                <div class="form-group">
                    <label for="active">Status</label>
                    <select name="active" id="active" class="form-control">
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="company_id">Company</label>
                    <select name="company_id" id="company_id" class="form-control">
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Add Customer</button>

                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

    <hr>
    <div class="row">
        <div class="col-6">
            <h3>Active Customers</h3>
            <ul>
                <?php $__currentLoopData = $activeCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($activeCustomer->name); ?> <span class="text-muted"><?php echo e($activeCustomer->company->name); ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-6">
            <h3>Inactive Customers</h3>
            <ul>
                <?php $__currentLoopData = $inactiveCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inactiveCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($inactiveCustomer->name); ?> <span class="text-muted"><?php echo e($inactiveCustomer->company->name); ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3><?php echo e($company->name); ?></h3>
                <ul>
                    <?php $__currentLoopData = $company->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($customer->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\frm9_opdr02\resources\views/internals/customers.blade.php ENDPATH**/ ?>